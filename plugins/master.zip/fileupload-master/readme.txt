=== About ===
name: File Upload
website: http://apps.ushahidi.com
description: Allows users to upload any file to reports and pages
version: 1.0
requires: 2.1
tested up to: 2.1
author: John Etherton
author website: http://johnetherton.com

== Description ==
Adds the ability to upload any file to the site and associate it with a report or a page. Note that for pages to work the following plugins need to either be added to a skin or customized

The "Insert file into description" link only works if the description box uses TinyMCE, which I recommend you do.

== Installation ==
1. Copy the entire /fileupload/ directory into your /plugins/ directory.
2. Activate the plugin.

== Changelog ==